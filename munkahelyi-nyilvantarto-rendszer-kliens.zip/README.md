[![Build Status](https://travis-ci.com/Problem-Solved-Group/munkahelyi-nyilvantarto-rendszer-kliens.svg?branch=main)](https://travis-ci.com/Problem-Solved-Group/munkahelyi-nyilvantarto-rendszer-kliens)
# Munkahelyi Nyilvántartó Rendszer Kliens

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 10.2.0.

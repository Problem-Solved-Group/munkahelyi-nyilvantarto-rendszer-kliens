import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddeditworkingtimeComponent } from './addeditworkingtime.component';

describe('AddeditworkingtimeComponent', () => {
  let component: AddeditworkingtimeComponent;
  let fixture: ComponentFixture<AddeditworkingtimeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddeditworkingtimeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddeditworkingtimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

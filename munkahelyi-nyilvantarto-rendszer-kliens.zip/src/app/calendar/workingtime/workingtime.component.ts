import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workingtime',
  templateUrl: './workingtime.component.html',
  styleUrls: ['./workingtime.component.scss']
})
export class WorkingtimeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HolidayrequestComponent } from './holidayrequest.component';

describe('HolidayrequestComponent', () => {
  let component: HolidayrequestComponent;
  let fixture: ComponentFixture<HolidayrequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HolidayrequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HolidayrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

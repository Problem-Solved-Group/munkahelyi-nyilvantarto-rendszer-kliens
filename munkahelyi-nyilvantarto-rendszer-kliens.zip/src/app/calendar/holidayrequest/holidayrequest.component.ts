import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-holidayrequest',
  templateUrl: './holidayrequest.component.html',
  styleUrls: ['./holidayrequest.component.scss']
})
export class HolidayrequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

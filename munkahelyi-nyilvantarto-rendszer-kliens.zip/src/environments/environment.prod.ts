export const environment = {
  production: true
};

export const baseUrl = "https://munkahelyi-nyilvantarto-rendsz.herokuapp.com"; 
